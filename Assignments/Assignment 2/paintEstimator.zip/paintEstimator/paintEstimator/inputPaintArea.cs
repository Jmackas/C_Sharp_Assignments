﻿namespace paintEstimator
{
    internal class inputPaintArea
    {
    }
}